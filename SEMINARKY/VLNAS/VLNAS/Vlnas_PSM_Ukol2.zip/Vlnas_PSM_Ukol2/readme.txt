Dobrý den,

zasílám Vám úkolu 2 :)

S pozdravem,

Martin Vlnas

=> martin.vlnas.cz@gmail.com