Dobrý den,

zasílám Vám seminární práci k PSM :)

S pozdravem,

Martin Vlnas

=> martin.vlnas.cz@gmail.com