Dobrý den,

zasílám Vám opravenou verzi úkolu 1 :)

S pozdravem,

Martin Vlnas

=> martin.vlnas.cz@gmail.com