Dobrý den,

zasílám Vám opravenou verzi úkolu 2 společně se seminární prací (taky oprava) :)

S pozdravem,

Martin Vlnas

=> martin.vlnas.cz@gmail.com